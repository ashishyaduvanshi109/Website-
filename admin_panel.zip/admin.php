<?php
session_start();
if (!isset($_SESSION['admin'])) {
  header("Location: admin-login.php");
  exit();
}
$conn = new mysqli("localhost", "root", "", "ashok_enterprise");
$result = $conn->query("SELECT * FROM form_data ORDER BY submitted_at DESC");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin Panel</title>
</head>
<body>
  <h2>Submitted Forms</h2>
  <a href="logout.php">Logout</a>
  <table border="1">
    <tr>
      <th>ID</th><th>Name</th><th>Phone</th><th>Email</th><th>Document</th><th>Time</th>
    </tr>
    <?php while($row = $result->fetch_assoc()) { ?>
    <tr>
      <td><?= $row['id'] ?></td>
      <td><?= $row['name'] ?></td>
      <td><?= $row['phone'] ?></td>
      <td><?= $row['email'] ?></td>
      <td><a href="<?= $row['document_path'] ?>" target="_blank">View</a></td>
      <td><?= $row['submitted_at'] ?></td>
    </tr>
    <?php } ?>
  </table>
</body>
</html>