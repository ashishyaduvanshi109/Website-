<!DOCTYPE html>
<html>
<head>
  <title>Admin Login</title>
</head>
<body>
  <form action="admin-check.php" method="POST">
    <h2>Admin Login</h2>
    <input type="text" name="username" placeholder="Username" required />
    <input type="password" name="password" placeholder="Password" required />
    <button type="submit">Login</button>
  </form>
</body>
</html>