<?php
session_start();
$user = $_POST['username'];
$pass = $_POST['password'];

if ($user == "admin" && $pass == "123456") {
  $_SESSION['admin'] = true;
  header("Location: admin.php");
} else {
  echo "<script>alert('Invalid login');window.location.href='admin-login.php';</script>";
}
?>